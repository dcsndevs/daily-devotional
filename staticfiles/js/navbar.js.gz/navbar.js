// $(document).ready(function(){
//     $(window).scroll(function() { // On scroll event
//       if ($(document).scrollTop() > 50) { // If user scrolls more than 50px
//         $('.navbar').addClass('dark-navbar'); // Add dark-navbar class to navbar
//       } else {
//         $('.navbar').removeClass('dark-navbar'); // Remove dark-navbar class from navbar
//       }
//     });
//   });
